import streamlit as st
from main import main_kpi, main_comparativo, main_lineas_producto

st.set_page_config(layout="wide")

menu = st.sidebar.radio("Navegación", [
    "📈 KPIs Generales",
    "📊 Comparativo Año vs Año",
    "📦 Tablero Estilo Excel"
])

if menu == "📈 KPIs Generales":
    main_kpi.run()
elif menu == "📊 Comparativo Año vs Año":
    main_comparativo.run()
elif menu == "📦 Tablero Estilo Excel":
    main_lineas_producto.run()
